# updater.py
import os, sys, time, tempfile, subprocess, urllib.request, argparse, shutil, hashlib

def sha256_of_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

def download(url, dest_path):
    with urllib.request.urlopen(url) as resp, open(dest_path, "wb") as out:
        out.write(resp.read())

def try_replace(src, dst, retries=60, delay=0.5):
    """
    Bezpieczna podmiana działającego pliku po zamknięciu aplikacji.
    Próbuje do 30 s (60 * 0.5s).
    """
    for _ in range(retries):
        try:
            # na Windows os.replace działa atomowo (jeśli dst nie jest zablokowany)
            os.replace(src, dst)
            return True
        except PermissionError:
            time.sleep(delay)
        except OSError:
            time.sleep(delay)
    return False

def self_delete():
    """
    Updater nie może skasować siebie od razu — robi to małym batch’em.
    """
    me = os.path.abspath(sys.argv[0])
    bat = os.path.join(tempfile.gettempdir(), f"cleanup_{int(time.time())}.bat")
    script = f"""@echo off
ping 127.0.0.1 -n 2 > nul
del "{me}" > nul 2>&1
del "%~f0" > nul 2>&1
"""
    with open(bat, "w", encoding="utf-8") as f:
        f.write(script)
    # start bez czekania
    subprocess.Popen(['cmd', '/c', bat], close_fds=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True, help="RAW URL do ARMIR.exe")
    ap.add_argument("--target", required=True, help="Ścieżka do lokalnego ARMIR.exe do podmiany")
    args = ap.parse_args()

    raw_url   = args.url
    target_exe = os.path.abspath(args.target)

    tmp_dir = tempfile.gettempdir()
    downloaded = os.path.join(tmp_dir, f"ARMIR_new_{int(time.time())}.exe")

    # 1) Pobierz nową wersję
    download(raw_url, downloaded)

    # (opcjonalnie) jeśli chcesz — weryfikacja „pusta”: plik nie może być zbyt mały
    if os.path.getsize(downloaded) < 100_000:  # 100 KB — prosta sanity-check
        raise RuntimeError("Pobrany plik wygląda podejrzanie mały.")

    # 2) Czekaj aż aplikacja się zamknie i podmień
    ok = try_replace(downloaded, target_exe, retries=120, delay=0.5)  # do 60 s
    if not ok:
        # sprzątaj i rzuć błąd
        try: os.remove(downloaded)
        except: pass
        raise RuntimeError("Nie udało się podmienić pliku (zajęty?).")

    # 3) Odpal nową wersję
    subprocess.Popen([target_exe], close_fds=True)

    # 4) Samo-sprzątanie
    self_delete()

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # ciche wyjście — to narzędzie działa w tle
        # jeśli chcesz logów, możesz dodać zapis do %APPDATA%
        sys.exit(1)
